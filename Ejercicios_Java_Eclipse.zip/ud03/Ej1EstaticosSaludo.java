package ud03;

public class Ej1EstaticosSaludo {
    public static void saludar() {
        System.out.println("¡Hola, bienvenidos a Java!");
    }

    public static void main(String[] args) {
        saludar();
    }
}
