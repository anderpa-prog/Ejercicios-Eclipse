package ud03;

import java.util.Scanner;

public class EjSencilloArrays3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] aNotasPGR = new int[5];
        int suma = 0;

        System.out.println("Por favor, introduce 5 notas:");
        for (int i = 0; i < aNotasPGR.length; i++) {
            System.out.print("Introduce la nota " + (i + 1) + ": ");
            aNotasPGR[i] = sc.nextInt();
            suma += aNotasPGR[i];
        }

        double media = (double) suma / aNotasPGR.length;
        System.out.println("-----------------------------------");
        System.out.println("La media es: " + media);

        sc.close();
    }
}
