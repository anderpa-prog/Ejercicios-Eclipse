package ud03;

import java.util.Scanner;

public class Ej7Mediatem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double[] aTemperaturas = new double[10];
        double temp, suma = 0, media;
        int posOcupadas = 0, mayores = 0, iguales = 0, inferiores = 0;
        boolean continuar = true;

        System.out.println("Introduce temperaturas (-999 finaliza):");
        while (posOcupadas < aTemperaturas.length && continuar) {
            System.out.print("Introduce la temperatura " + (posOcupadas + 1) + ": ");
            temp = sc.nextDouble();

            if (temp == -999) {
                continuar = false;
            } else {
                aTemperaturas[posOcupadas] = temp;
                posOcupadas++;
            }
        }

        if (posOcupadas > 0) {
            for (int i = 0; i < posOcupadas; i++) {
                suma += aTemperaturas[i];
            }
            media = suma / posOcupadas;

            for (int i = 0; i < posOcupadas; i++) {
                if (aTemperaturas[i] > media) {
                    mayores++;
                } else if (aTemperaturas[i] < media) {
                    inferiores++;
                } else {
                    iguales++;
                }
            }

            System.out.println("-----------------------------------");
            System.out.println("Total de temperaturas introducidas: " + posOcupadas);
            System.out.println("Temperaturas introducidas:");
            for (int i = 0; i < posOcupadas; i++) {
                System.out.print("Temperatura " + (i + 1) + ": " + aTemperaturas[i] + ", ");
            }
            System.out.println("\nTemperatura media: " + media + " °C");
            System.out.println("Número de temperaturas mayores que la media: " + mayores);
            System.out.println("Número de temperaturas iguales a la media: " + iguales);
            System.out.println("Número de temperaturas inferiores a la media: " + inferiores);
        } else {
            System.out.println("No se introdujo ninguna temperatura válida.");
        }

        sc.close();
    }
}
