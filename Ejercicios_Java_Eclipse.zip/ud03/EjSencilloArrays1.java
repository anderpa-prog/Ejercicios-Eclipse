package ud03;

public class EjSencilloArrays1 {
    public static void main(String[] args) {
        String[] aNombres = {"Romana", "Ethan", "Muhammed", "Eneko", "June"};
        for (int i = 0; i < aNombres.length; i++) {
            System.out.println("aNombres[" + i + "] = " + aNombres[i]);
        }
    }
}
