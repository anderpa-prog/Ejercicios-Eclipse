package ud03;

public class TempSemana {
    public static void mostrar(double[] aTemp, String[] aDias) {
        System.out.println("Temperaturas de la semana");
        for (int i = 0; i < aDias.length; i++) {
            System.out.println(aDias[i] + ": " + aTemp[i] + " °C");
        }
        System.out.println("-----------------------------------");
    }

    public static void mediaFahrenheit(double[] aTemp) {
        double suma = 0;
        for (int i = 0; i < aTemp.length; i++) {
            suma += aTemp[i];
        }
        double media = Math.round((suma / aTemp.length) * 100.0) / 100.0;
        double mediaF = Math.round(((media * 9.0 / 5.0) + 32) * 100.0) / 100.0;

        System.out.println("Temperatura Media");
        System.out.println("La media de la semana es: " + mediaF + " °F (equivale a " + media + " °C)");
        System.out.println("-----------------------------------");
    }

    public static void tempMinMax(double[] aTemp, String[] aDias) {
        double maxTemp = aTemp[0];
        double minTemp = aTemp[0];
        int posMax = 0;
        int posMin = 0;

        for (int i = 0; i < aTemp.length; i++) {
            if (aTemp[i] > maxTemp) {
                maxTemp = aTemp[i];
                posMax = i;
            }
            if (aTemp[i] < minTemp) {
                minTemp = aTemp[i];
                posMin = i;
            }
        }

        System.out.println("Día más caluroso: " + aDias[posMax] + " con " + maxTemp + " °C.");
        System.out.println("Día más frío: " + aDias[posMin] + " con " + minTemp + " °C.");
        System.out.println("-----------------------------------");
    }

    public static void compMedia(double[] aTemp, String[] aDias) {
        double suma = 0;
        for (int i = 0; i < aTemp.length; i++) {
            suma += aTemp[i];
        }
        double media = suma / aTemp.length;

        System.out.println("Días por encima de la media:");
        for (int i = 0; i < aTemp.length; i++) {
            if (aTemp[i] > media) {
                System.out.println(" > " + aDias[i] + " (" + aTemp[i] + " °C)");
            }
        }

        System.out.println("Días por debajo de la media:");
        for (int i = 0; i < aTemp.length; i++) {
            if (aTemp[i] < media) {
                System.out.println(" > " + aDias[i] + " (" + aTemp[i] + " °C)");
            }
        }
    }

    public static void main(String[] args) {
        String[] aDias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        double[] aTemp = {26.5, 24.1, 20.4, 19.9, 23.0, 25.3, 28.1};

        mostrar(aTemp, aDias);
        mediaFahrenheit(aTemp);
        tempMinMax(aTemp, aDias);
        compMedia(aTemp, aDias);
    }
}
