package ud03;

import java.util.Scanner;

public class Ej5Numveces {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] contador = new int[10];
        int maxSize = 20;
        int numEntradas = 0;
        int num;
        boolean continuar = true;

        System.out.println("Introduce números de 0 a 9");
        System.out.println("(Un valor negativo finaliza la entrada, o al alcanzar " + maxSize + " elementos)");

        while (numEntradas < maxSize && continuar) {
            System.out.print("Introduce un número: ");
            num = sc.nextInt();

            if (num < 0) {
                continuar = false;
            } else {
                if (num >= 0 && num <= 9) {
                    contador[num]++;
                    numEntradas++;
                } else {
                    System.out.println("Número fuera de rango. Debe ser un valor comprendido entre 0 y 9.");
                }
            }
        }

        System.out.println("-----------------------------------");
        for (int i = 0; i < contador.length; i++) {
            System.out.println("El número " + i + " se ha introducido " + contador[i] + " veces.");
        }

        sc.close();
    }
}
