package ud03;

public class LluviaMeses {
    public static void mostrarLxM(String[] aMeses, int[] aLitros) {
        System.out.println("======= Litros de lluvia por mes =======");
        for (int i = 0; i < aMeses.length; i++) {
            System.out.println("En " + aMeses[i] + " han llovido " + aLitros[i] + " litros.");
        }
    }

    public static void masLluvioso(String[] aMeses, int[] aLitros) {
        int maxLitros = aLitros[0];
        int posMax = 0;
        for (int i = 0; i < aLitros.length; i++) {
            if (aLitros[i] > maxLitros) {
                maxLitros = aLitros[i];
                posMax = i;
            }
        }
        System.out.println("El mes más lluvioso fue " + aMeses[posMax] + " con " + maxLitros + " L/m^2");
    }

    public static void main(String[] args) {
        String[] aMeses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo"};
        int[] aLitros = {123, 333, 180, 211, 90};
        mostrarLxM(aMeses, aLitros);
        masLluvioso(aMeses, aLitros);
    }
}
