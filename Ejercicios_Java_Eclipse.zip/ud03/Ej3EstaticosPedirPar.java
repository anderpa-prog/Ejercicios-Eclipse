package ud03;

import java.util.Scanner;

public class Ej3EstaticosPedirPar {
    public static int pedirNumero(Scanner sc) {
        int numero;
        System.out.println("Introduce un número entero:");
        numero = sc.nextInt();
        sc.nextLine();
        return numero;
    }

    public static boolean esPar(int n) {
        boolean resultado;
        if (n % 2 == 0) {
            resultado = true;
        } else {
            resultado = false;
        }
        return resultado;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numeroLeido = pedirNumero(sc);
        boolean par = esPar(numeroLeido);

        if (par) {
            System.out.println("El número " + numeroLeido + " es par.");
        } else {
            System.out.println("El número " + numeroLeido + " es impar.");
        }

        sc.close();
    }
}
