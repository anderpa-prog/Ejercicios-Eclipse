package ud03;

import java.util.Scanner;

public class Ej6Medianum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] aNumeros = new int[5];
        int posOcupadas = 0;
        int num = 0;
        boolean continuar = true;
        int suma = 0;

        System.out.println("Introduce números enteros (un número negativo finaliza la entrada):");
        while (posOcupadas < aNumeros.length && continuar) {
            System.out.print("Introduce el número " + (posOcupadas + 1) + ": ");
            num = sc.nextInt();

            if (num < 0) {
                continuar = false;
            } else {
                aNumeros[posOcupadas] = num;
                posOcupadas++;
            }
        }

        if (posOcupadas > 0) {
            for (int i = 0; i < posOcupadas; i++) {
                suma += aNumeros[i];
            }
            double media = (double) suma / posOcupadas;

            System.out.println("-----------------------------------");
            System.out.println("Cantidad de números introducidos: " + posOcupadas);
            System.out.println("La suma total es: " + suma);
            System.out.println("La media es: " + media);
        } else {
            System.out.println("No se introdujo ningún número válido para calcular la media.");
        }

        sc.close();
    }
}
