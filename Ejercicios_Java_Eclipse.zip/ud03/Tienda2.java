package ud03;

import java.util.Scanner;

public class Tienda2 {
    public static boolean estaVacio(String[] aArticulos) {
        boolean vacio = true;
        int i = 0;
        while (i < aArticulos.length && vacio) {
            if (aArticulos[i] != null) {
                vacio = false;
            }
            i++;
        }
        return vacio;
    }

    public static int buscarPos(String[] aArticulos, String articulo) {
        int posEncontrado = -1;
        int i = 0;
        boolean encontrado = false;
        while (i < aArticulos.length && !encontrado) {
            if (aArticulos[i] != null && aArticulos[i].equalsIgnoreCase(articulo)) {
                posEncontrado = i;
                encontrado = true;
            }
            i++;
        }
        return posEncontrado;
    }

    public static void introducirProPre(String[] aArticulos, double[] aPrecios, Scanner sc, String articulo, double precio) {
        int i = 0;
        int posLibre = -1;
        boolean encontradoLibre = false;

        while (i < aArticulos.length && !encontradoLibre) {
            if (aArticulos[i] == null) {
                posLibre = i;
                encontradoLibre = true;
            }
            i++;
        }

        if (posLibre == -1) {
            System.out.println("No hay espacio libre.");
        } else {
            System.out.println("Introduce el nombre del artículo:");
            articulo = sc.next();
            aArticulos[posLibre] = articulo;
            System.out.println("Introduce el precio del producto:");
            precio = sc.nextDouble();
            aPrecios[posLibre] = precio;
            System.out.println("El artículo ha sido introducido.");
        }
    }

    public static void mostrarProductos(String[] aArticulos, double[] aPrecios) {
        if (estaVacio(aArticulos)) {
            System.out.println("No hay productos en la tienda.");
        } else {
            int i = 0;
            while (i < aArticulos.length) {
                if (aArticulos[i] != null) {
                    System.out.println("El precio del artículo " + aArticulos[i] + " es de " + aPrecios[i] + " €");
                }
                i++;
            }
        }
    }

    public static void mostrarPrecio(Scanner sc, String[] aArticulos, double[] aPrecios, String articulo, double precio) {
        if (estaVacio(aArticulos)) {
            System.out.println("No hay artículos en la tienda.");
        } else {
            System.out.println("¿Cuál es el nombre del artículo?");
            articulo = sc.next();
            int posicion = buscarPos(aArticulos, articulo);
            if (posicion != -1) {
                precio = aPrecios[posicion];
                System.out.println("El precio del artículo " + aArticulos[posicion] + " es de " + precio + " €");
            } else {
                System.out.println("El artículo no existe.");
            }
        }
    }

    public static void obtenerIva(Scanner sc, String[] aArticulos, double[] aPrecios, String articulo, double precio) {
        if (estaVacio(aArticulos)) {
            System.out.println("No hay artículos en la tienda.");
        } else {
            System.out.println("¿Cuál es el nombre del artículo?");
            articulo = sc.next();
            int posicion = buscarPos(aArticulos, articulo);
            if (posicion != -1) {
                precio = aPrecios[posicion];
                double iva = precio * 0.21;
                System.out.println("El IVA del artículo " + aArticulos[posicion] + " es " + iva + "€");
            } else {
                System.out.println("El artículo no existe.");
            }
        }
    }

    public static void modPrecio(Scanner sc, String[] aArticulos, double[] aPrecios, String articulo, double precio) {
        if (estaVacio(aArticulos)) {
            System.out.println("No hay artículos en la tienda.");
        } else {
            System.out.println("¿Cuál es el nombre del artículo?");
            articulo = sc.next();
            int posicion = buscarPos(aArticulos, articulo);
            if (posicion != -1) {
                System.out.println("Introduce el nuevo precio del producto:");
                precio = sc.nextDouble();
                aPrecios[posicion] = precio;
                System.out.println("El precio del " + aArticulos[posicion] + " ha sido modificado.");
            } else {
                System.out.println("El artículo no existe.");
            }
        }
    }

    public static void eliminar(String[] aArticulos, double[] aPrecios, Scanner sc, String articulo) {
        if (estaVacio(aArticulos)) {
            System.out.println("No hay artículos en la tienda.");
        } else {
            System.out.println("¿Cuál es el nombre del artículo que quieres eliminar?");
            articulo = sc.next();
            int posicion = buscarPos(aArticulos, articulo);
            if (posicion != -1) {
                System.out.println("¿Estás segur@ de que quieres eliminarlo?");
                String confirmacion = sc.next();
                if (confirmacion.equalsIgnoreCase("Si")) {
                    aArticulos[posicion] = null;
                    aPrecios[posicion] = 0.0;
                    System.out.println("Producto eliminado correctamente");
                } else {
                    System.out.println("Operación cancelada.");
                }
            } else {
                System.out.println("El artículo no existe.");
            }
        }
    }

    public static void salir() {
        System.out.println("Saliendo del programa...");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] aArticulos = new String[50];
        double[] aPrecios = new double[50];
        int opcion = 0;
        String articulo = "";
        double precio = 0;

        do {
            System.out.println("************************************");
            System.out.println("1.- Añadir artículos y precios");
            System.out.println("2.- Mostrar productos de la tienda");
            System.out.println("3.- Obtener el precio de un producto");
            System.out.println("4.- Obtener el IVA de un producto");
            System.out.println("5.- Modificar el precio de un producto");
            System.out.println("6.- Eliminar un producto");
            System.out.println("7.- Salir");
            System.out.println("¿Qué quieres hacer?");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    introducirProPre(aArticulos, aPrecios, sc, articulo, precio);
                    break;
                case 2:
                    mostrarProductos(aArticulos, aPrecios);
                    break;
                case 3:
                    mostrarPrecio(sc, aArticulos, aPrecios, articulo, precio);
                    break;
                case 4:
                    obtenerIva(sc, aArticulos, aPrecios, articulo, precio);
                    break;
                case 5:
                    modPrecio(sc, aArticulos, aPrecios, articulo, precio);
                    break;
                case 6:
                    eliminar(aArticulos, aPrecios, sc, articulo);
                    break;
                case 7:
                    salir();
                    break;
                default:
                    System.out.println("Opción no válida, inténtalo de nuevo.");
                    break;
            }
        } while (opcion != 7);

        sc.close();
    }
}
