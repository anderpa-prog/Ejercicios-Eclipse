package ud03;

import java.util.Scanner;

public class Ej2EstaticosSaludoPersonalizado {
    public static void mostrarNombre(String nombre) {
        System.out.println("Hola " + nombre + "!");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nombreUsuario;

        System.out.println("¿Cómo te llamas?");
        nombreUsuario = sc.nextLine();

        mostrarNombre(nombreUsuario);
        sc.close();
    }
}
