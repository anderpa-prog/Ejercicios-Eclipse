package examenes;

public class NaveEspacial {
    private String nombre;
    private int anioCreacion;
    private int anioLanzamiento;
    private int capacidadTotal;
    private int tripulantesNecesarios;

    public NaveEspacial() {
        this.nombre = "";
        this.anioCreacion = 0;
        this.anioLanzamiento = 0;
        this.capacidadTotal = 0;
        this.tripulantesNecesarios = 0;
    }

    public NaveEspacial(String nombre, int anioCreacion, int anioLanzamiento, int capacidadTotal, int tripulantesNecesarios) {
        this.nombre = nombre;
        this.anioCreacion = anioCreacion;
        this.anioLanzamiento = anioLanzamiento;
        this.capacidadTotal = capacidadTotal;
        this.tripulantesNecesarios = tripulantesNecesarios;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAnioCreacion() {
        return anioCreacion;
    }

    public void setAnioCreacion(int anioCreacion) {
        this.anioCreacion = anioCreacion;
    }

    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }

    public void setAnioLanzamiento(int anioLanzamiento) {
        this.anioLanzamiento = anioLanzamiento;
    }

    public int getCapacidadTotal() {
        return capacidadTotal;
    }

    public void setCapacidadTotal(int capacidadTotal) {
        this.capacidadTotal = capacidadTotal;
    }

    public int getTripulantesNecesarios() {
        return tripulantesNecesarios;
    }

    public void setTripulantesNecesarios(int tripulantesNecesarios) {
        this.tripulantesNecesarios = tripulantesNecesarios;
    }

    @Override
    public String toString() {
        return "Nave Espacial: " + nombre +
               ", Año de Creación: " + anioCreacion +
               ", Año de Lanzamiento: " + anioLanzamiento +
               ", Capacidad Total: " + capacidadTotal +
               ", Tripulantes Necesarios: " + tripulantesNecesarios;
    }

    public int calcularAntiguedad(int anioActual) {
        return anioActual - this.anioLanzamiento;
    }

    public boolean admitePasajeros() {
        if (this.capacidadTotal > this.tripulantesNecesarios) {
            return true;
        } else {
            return false;
        }
    }
}
