package examenes;

public class Asignatura {
    private String nombre;
    private String curso;
    private int numeroAlumnos;
    private int numeroSuspensos;

    public Asignatura(String nombre, String curso) {
        this.nombre = nombre;
        this.curso = curso;
        this.numeroAlumnos = 0;
        this.numeroSuspensos = 0;
    }

    public Asignatura(String nombre, String curso, int numeroAlumnos, int numeroSuspensos) {
        this.nombre = nombre;
        this.curso = curso;
        this.numeroAlumnos = numeroAlumnos;
        this.numeroSuspensos = numeroSuspensos;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getCurso() {
        return this.curso;
    }

    public int getNumeroAlumnos() {
        return this.numeroAlumnos;
    }

    public int getNumeroSuspensos() {
        return this.numeroSuspensos;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public void setNumeroAlumnos(int numeroAlumnos) {
        this.numeroAlumnos = numeroAlumnos;
    }

    public void setNumeroSuspensos(int numeroSuspensos) {
        this.numeroSuspensos = numeroSuspensos;
    }

    public int obtenerNumeroAprobados() {
        int aprobados = this.numeroAlumnos - this.numeroSuspensos;
        if (aprobados < 0) {
            aprobados = 0;
        }
        return aprobados;
    }

    public double porcentajeAprobados() {
        double porcentaje;
        int aprobados = this.obtenerNumeroAprobados();
        if (this.numeroAlumnos <= 0) {
            porcentaje = 0.0;
        } else {
            porcentaje = ((double) aprobados / this.numeroAlumnos) * 100.0;
        }
        return porcentaje;
    }

    @Override
    public String toString() {
        return "Asignatura [Nombre=" + this.nombre +
               ", Curso=" + this.curso +
               ", Alumnos matriculados=" + this.numeroAlumnos +
               ", Suspensos=" + this.numeroSuspensos +
               ", Aprobados=" + this.obtenerNumeroAprobados() +
               ", % Aprobados=" + this.porcentajeAprobados() + "%]";
    }
}
