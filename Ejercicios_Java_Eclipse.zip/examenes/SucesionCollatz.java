package examenes;

import java.util.Scanner;

public class SucesionCollatz {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero;
        int pasos = 0;

        System.out.print("Introduce un número entero positivo: ");
        numero = sc.nextInt();

        while (numero <= 0) {
            System.out.print("Introduce un número entero positivo válido: ");
            numero = sc.nextInt();
        }

        System.out.print("Sucesión: " + numero);
        while (numero != 1) {
            if (numero % 2 == 0) {
                numero = numero / 2;
            } else {
                numero = numero * 3 + 1;
            }
            System.out.print(", " + numero);
            pasos++;
        }

        System.out.println();
        System.out.println("Número de pasos realizados: " + pasos);
        sc.close();
    }
}
