package examenes;

import java.util.Scanner;

public class Fibonacci {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        int a = 1;
        int b = 1;
        int c;

        System.out.print("Introduce un número mayor que 1: ");
        n = sc.nextInt();

        while (n <= 1) {
            System.out.println("Error: El número introducido debe ser mayor que 1.");
            System.out.print("Introduce un número mayor que 1: ");
            n = sc.nextInt();
        }

        System.out.print("La serie es: ");
        for (int i = 1; i <= n; i++) {
            if (i == 1) {
                System.out.print(a);
            } else {
                System.out.print(" " + b);
                c = a + b;
                a = b;
                b = c;
            }
        }

        System.out.println();
        sc.close();
    }
}
