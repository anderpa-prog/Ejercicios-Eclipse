package examenes;

import java.util.Scanner;

public class ContadorVocales {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String palabra;
        int vocales = 0;

        System.out.print("Introduce una palabra: ");
        palabra = sc.nextLine();

        for (int i = 0; i < palabra.length(); i++) {
            char letra = palabra.charAt(i);
            if (letra == 'a' || letra == 'A' ||
                letra == 'e' || letra == 'E' ||
                letra == 'i' || letra == 'I' ||
                letra == 'o' || letra == 'O' ||
                letra == 'u' || letra == 'U') {
                vocales++;
            }
        }

        if (vocales == 0) {
            System.out.println("No contiene vocales");
        } else if (vocales == 1) {
            System.out.println("Contiene 1 vocal");
        } else {
            System.out.println("Contiene " + vocales + " vocales");
        }

        sc.close();
    }
}
