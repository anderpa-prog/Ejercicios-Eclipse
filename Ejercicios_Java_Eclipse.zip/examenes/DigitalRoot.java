package examenes;

import java.util.Scanner;

public class DigitalRoot {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero;
        int aux;
        int sumaDigitos;

        System.out.print("Introduce un número entero positivo: ");
        numero = sc.nextInt();

        while (numero <= 0) {
            System.out.println("Error: El número debe ser un entero positivo.");
            System.out.print("Introduce un número entero positivo: ");
            numero = sc.nextInt();
        }

        aux = numero;

        while (aux >= 10) {
            sumaDigitos = 0;
            while (aux > 0) {
                sumaDigitos += aux % 10;
                aux /= 10;
            }
            aux = sumaDigitos;
        }

        System.out.println("El número raíz (digital root) de " + numero + " es: " + aux);
        sc.close();
    }
}
