package examenes;

import java.util.Scanner;

public class NumeroCapicua {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero;
        int original;
        int invertido = 0;
        int temp;
        int digito;

        System.out.print("Introduce un número entero positivo: ");
        numero = sc.nextInt();

        while (numero <= 0) {
            System.out.print("Introduce un número entero positivo válido: ");
            numero = sc.nextInt();
        }

        original = numero;
        temp = numero;

        while (temp > 0) {
            digito = temp % 10;
            invertido = invertido * 10 + digito;
            temp /= 10;
        }

        if (original == invertido) {
            System.out.println("El número " + original + " es capicúa.");
        } else {
            System.out.println("El número " + original + " no es capicúa.");
        }

        sc.close();
    }
}
