package examenes;

import java.util.Scanner;

public class AsignaturaMain {
    public static int buscarAsignatura(Asignatura[] aAsignaturas, int totalAsignaturas, String nombreBuscado) {
        int i;
        int encontrado = -1;
        for (i = 0; i < totalAsignaturas; i++) {
            if (aAsignaturas[i].getNombre().equalsIgnoreCase(nombreBuscado)) {
                encontrado = i;
            }
        }
        return encontrado;
    }

    public static int contarAsignaturas(Asignatura[] aAsignaturas) {
        int i;
        int contador = 0;
        for (i = 0; i < aAsignaturas.length; i++) {
            if (aAsignaturas[i] != null) {
                contador++;
            }
        }
        return contador;
    }

    public static void introducirAsignaturas(Asignatura[] aAsignaturas, Scanner sc) {
        String respuesta = "SI";
        String nombre;
        int indiceExistente;
        String curso;
        int matriculados;
        int suspensos;
        int totalAsignaturas;
        boolean continuar = true;

        while (respuesta.equalsIgnoreCase("SI") && continuar) {
            totalAsignaturas = contarAsignaturas(aAsignaturas);
            if (totalAsignaturas >= 100) {
                System.out.println("Se ha alcanzado el límite máximo de 100 asignaturas.");
                continuar = false;
            } else {
                System.out.print("Introduce el nombre de la asignatura: ");
                nombre = sc.nextLine().trim();
                indiceExistente = buscarAsignatura(aAsignaturas, totalAsignaturas, nombre);
                if (indiceExistente != -1) {
                    System.out.println("Esa asignatura ya existe");
                } else {
                    System.out.print("Introduce el curso de la asignatura: ");
                    curso = sc.nextLine().trim();
                    System.out.print("Introduce el número de matriculados de la asignatura: ");
                    matriculados = sc.nextInt();
                    System.out.print("Introduce el número de suspensos de la asignatura: ");
                    suspensos = sc.nextInt();
                    sc.nextLine();

                    while (suspensos > matriculados || suspensos < 0 || matriculados < 0) {
                        System.out.println("Error: El número de suspensos no puede ser superior al de matriculados ni negativo.");
                        System.out.print("Introduce el número de suspensos de la asignatura: ");
                        suspensos = sc.nextInt();
                        sc.nextLine();
                    }

                    aAsignaturas[totalAsignaturas] = new Asignatura(nombre, curso, matriculados, suspensos);
                    System.out.println("La asignatura ha sido introducida");
                }

                totalAsignaturas = contarAsignaturas(aAsignaturas);
                if (totalAsignaturas < 100) {
                    System.out.print("¿Quieres introducir otra asignatura? ");
                    respuesta = sc.nextLine().trim();
                } else {
                    System.out.println("Se ha alcanzado el límite máximo de 100 asignaturas.");
                    respuesta = "NO";
                }
            }
        }
    }

    public static void mostrarPorcentajeCurso(Asignatura[] aAsignaturas, Scanner sc) {
        int totalAsignaturas = contarAsignaturas(aAsignaturas);
        if (totalAsignaturas == 0) {
            System.out.println("Error: No hay asignaturas introducidas todavía.");
        } else {
            System.out.print("Introduce el curso de la asignatura: ");
            String cursoBuscado = sc.nextLine().trim();
            int contadorCurso = 0;
            for (int i = 0; i < totalAsignaturas; i++) {
                if (aAsignaturas[i].getCurso().equalsIgnoreCase(cursoBuscado)) {
                    double porcentaje = aAsignaturas[i].porcentajeAprobados();
                    System.out.println("En la asignatura " + aAsignaturas[i].getNombre() + " el porcentaje de aprobados es " + porcentaje + "%");
                    contadorCurso++;
                }
            }
            if (contadorCurso == 0) {
                System.out.println("No hay asignaturas para ese curso");
            }
        }
    }

    public static void ordenarAsignaturas(Asignatura[] aAsignaturas) {
        int totalAsignaturas = contarAsignaturas(aAsignaturas);
        if (totalAsignaturas == 0) {
            System.out.println("Error: No hay asignaturas introducidas todavía.");
        } else {
            Asignatura[] aOrdenadas = new Asignatura[totalAsignaturas];
            for (int i = 0; i < totalAsignaturas; i++) {
                aOrdenadas[i] = aAsignaturas[i];
            }
            for (int i = 0; i < totalAsignaturas - 1; i++) {
                for (int j = 0; j < totalAsignaturas - 1 - i; j++) {
                    if (aOrdenadas[j].obtenerNumeroAprobados() < aOrdenadas[j + 1].obtenerNumeroAprobados()) {
                        Asignatura aux = aOrdenadas[j];
                        aOrdenadas[j] = aOrdenadas[j + 1];
                        aOrdenadas[j + 1] = aux;
                    }
                }
            }
            for (int i = 0; i < totalAsignaturas; i++) {
                System.out.println(aOrdenadas[i]);
            }
        }
    }

    public static void modificarAsignatura(Asignatura[] aAsignaturas, Scanner sc) {
        int totalAsignaturas = contarAsignaturas(aAsignaturas);
        if (totalAsignaturas == 0) {
            System.out.println("Error: No hay asignaturas introducidas todavía.");
        } else {
            System.out.print("Introduce el nombre de la asignatura: ");
            String nombreModificar = sc.nextLine().trim();
            int indiceModificar = buscarAsignatura(aAsignaturas, totalAsignaturas, nombreModificar);
            if (indiceModificar == -1) {
                System.out.println("No existe ninguna asignatura con ese nombre.");
            } else {
                System.out.print("¿Quieres cambiar el número de alumnos matriculados? (SI/NO) ");
                String respMod = sc.nextLine().trim();
                if (respMod.equalsIgnoreCase("SI")) {
                    System.out.print("Introduce el número de alumnos matriculados: ");
                    int matriculados = sc.nextInt();
                    sc.nextLine();
                    aAsignaturas[indiceModificar].setNumeroAlumnos(matriculados);
                }

                System.out.print("¿Quieres cambiar el número de suspensos? (SI/NO) ");
                respMod = sc.nextLine().trim();
                if (respMod.equalsIgnoreCase("SI")) {
                    System.out.print("Introduce el número de suspensos: ");
                    int suspensos = sc.nextInt();
                    sc.nextLine();
                    aAsignaturas[indiceModificar].setNumeroSuspensos(suspensos);
                }

                if (aAsignaturas[indiceModificar].getNumeroSuspensos() > aAsignaturas[indiceModificar].getNumeroAlumnos()) {
                    System.out.println("Aviso: Los suspensos superaban a los matriculados. Se han ajustado los suspensos al total de matriculados.");
                    aAsignaturas[indiceModificar].setNumeroSuspensos(aAsignaturas[indiceModificar].getNumeroAlumnos());
                }
                System.out.println("Asignatura modificada correctamente.");
            }
        }
    }

    public static void mostrarTodas(Asignatura[] aAsignaturas) {
        int totalAsignaturas = contarAsignaturas(aAsignaturas);
        if (totalAsignaturas == 0) {
            System.out.println("Error: No hay asignaturas introducidas todavía.");
        } else {
            for (int i = 0; i < totalAsignaturas; i++) {
                System.out.println(aAsignaturas[i]);
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Asignatura[] aAsignaturas = new Asignatura[100];
        int opcion = 0;

        do {
            System.out.println("\n================ GESTIÓN DE ASIGNATURAS ================");
            System.out.println("1. Introducir las asignaturas");
            System.out.println("2. Mostrar el porcentaje de aprobados de las asignaturas de un curso");
            System.out.println("3. Ordenar las asignaturas por número de aprobados");
            System.out.println("4. Modificar datos de una asignatura concreta");
            System.out.println("5. Mostrar todas las asignaturas");
            System.out.println("6. Salir");
            System.out.print("¿Qué quieres hacer? ");

            if (sc.hasNextInt()) {
                opcion = sc.nextInt();
                sc.nextLine();
            } else {
                System.out.println("Error: Introduce un número de opción válido.");
                sc.nextLine();
                opcion = 0;
                continue;
            }

            switch (opcion) {
                case 1:
                    introducirAsignaturas(aAsignaturas, sc);
                    break;
                case 2:
                    mostrarPorcentajeCurso(aAsignaturas, sc);
                    break;
                case 3:
                    ordenarAsignaturas(aAsignaturas);
                    break;
                case 4:
                    modificarAsignatura(aAsignaturas, sc);
                    break;
                case 5:
                    mostrarTodas(aAsignaturas);
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Introduce un número del 1 al 6.");
                    break;
            }
        } while (opcion != 6);

        sc.close();
    }
}
