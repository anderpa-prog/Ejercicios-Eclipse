package examenes;

import java.time.LocalDate;
import java.util.Scanner;

public class NaveEspacialMain2 {
    public static int contarNaves(NaveEspacial[] naves) {
        int total = 0;
        for (int i = 0; i < naves.length; i++) {
            if (naves[i] != null) {
                total++;
            }
        }
        return total;
    }

    public static int buscarNave(NaveEspacial[] naves, String nombre) {
        int i;
        boolean encontrada = false;
        for (i = 0; i < naves.length && !encontrada; i++) {
            if (naves[i] != null && naves[i].getNombre().equalsIgnoreCase(nombre)) {
                encontrada = true;
            }
        }
        if (encontrada) {
            return i - 1;
        } else {
            return -1;
        }
    }

    public static void anadirNaves(NaveEspacial[] naves, Scanner sc) {
        boolean seguirAñadiendo = true;
        String nombre;
        int anioCreacion;
        int anioLanzamiento = 0;
        boolean anioValido;
        int capacidadTotal;
        int tripulantesNecesarios;
        String respuesta;
        int indice;
        int totalNaves;

        while (seguirAñadiendo) {
            totalNaves = contarNaves(naves);
            if (totalNaves >= 50) {
                System.out.println("Error: Se ha alcanzado el límite máximo de 50 naves.");
                seguirAñadiendo = false;
            } else {
                System.out.print("Introduce el nombre de la nave: ");
                nombre = sc.nextLine();
                indice = buscarNave(naves, nombre);
                if (indice != -1) {
                    System.out.println("Ya existe una nave con ese nombre.");
                } else {
                    System.out.print("Introduce el año de creación: ");
                    anioCreacion = sc.nextInt();
                    anioValido = false;
                    while (!anioValido) {
                        System.out.print("Introduce el año de lanzamiento: ");
                        anioLanzamiento = sc.nextInt();
                        if (anioLanzamiento < anioCreacion) {
                            System.out.println("Error: El año de lanzamiento no puede ser anterior al año de creación.");
                        } else {
                            anioValido = true;
                        }
                    }
                    System.out.print("Introduce la capacidad total de personas: ");
                    capacidadTotal = sc.nextInt();
                    System.out.print("Introduce el número de tripulantes necesarios: ");
                    tripulantesNecesarios = sc.nextInt();
                    sc.nextLine();

                    naves[totalNaves] = new NaveEspacial(nombre, anioCreacion, anioLanzamiento, capacidadTotal, tripulantesNecesarios);
                    System.out.println("Nave añadida exitosamente.");
                }

                System.out.print("¿Quieres seguir introduciendo naves? (si/no): ");
                respuesta = sc.nextLine();
                if (respuesta.equalsIgnoreCase("no")) {
                    seguirAñadiendo = false;
                }
            }
        }
    }

    public static void mostrarNavesAntiguedad(NaveEspacial[] naves, Scanner sc) {
        int totalNaves = contarNaves(naves);
        if (totalNaves == 0) {
            System.out.println("Error: No hay naves registradas en el sistema.");
            return;
        }
        int anioActual = LocalDate.now().getYear();
        int encontradas = 0;
        System.out.print("Introduce la antigüedad mínima: ");
        int antiguedadMinima = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < totalNaves; i++) {
            int antiguedadNave = naves[i].calcularAntiguedad(anioActual);
            if (antiguedadNave >= antiguedadMinima) {
                System.out.println(naves[i].toString());
                encontradas++;
            }
        }
        if (encontradas == 0) {
            System.out.println("No se encontraron naves con antigüedad superior o igual a " + antiguedadMinima);
        }
    }

    public static void ordenarNavesPorAnio(NaveEspacial[] naves) {
        int totalNaves = contarNaves(naves);
        if (totalNaves == 0) {
            System.out.println("Error: No hay naves registradas en el sistema.");
            return;
        }

        for (int i = 0; i < totalNaves - 1; i++) {
            for (int j = 0; j < totalNaves - i - 1; j++) {
                if (naves[j].getAnioLanzamiento() < naves[j + 1].getAnioLanzamiento()) {
                    NaveEspacial auxiliar = naves[j];
                    naves[j] = naves[j + 1];
                    naves[j + 1] = auxiliar;
                }
            }
        }

        System.out.println("Naves ordenadas por año de lanzamiento (descendente):");
        for (int k = 0; k < totalNaves; k++) {
            System.out.println(naves[k].toString());
        }
    }

    public static void modificarCapacidadPasajeros(NaveEspacial[] naves, Scanner sc) {
        int totalNaves = contarNaves(naves);
        if (totalNaves == 0) {
            System.out.println("Error: No hay naves registradas en el sistema.");
            return;
        }
        int navesPasajeros = 0;
        for (int i = 0; i < totalNaves; i++) {
            if (naves[i].admitePasajeros()) {
                navesPasajeros++;
                System.out.println(naves[i].toString());
                System.out.print("¿Desea cambiar la capacidad total de la nave? (si/no): ");
                String respuesta = sc.nextLine();
                if (respuesta.equalsIgnoreCase("si")) {
                    boolean capacidadValida = false;
                    while (!capacidadValida) {
                        System.out.print("Introduce la nueva capacidad para la nave " + naves[i].getNombre() + ": ");
                        int nuevaCapacidad = sc.nextInt();
                        sc.nextLine();
                        if (nuevaCapacidad < naves[i].getTripulantesNecesarios()) {
                            System.out.println("Error: La nueva capacidad no puede ser menor que el número de tripulantes necesarios.");
                        } else {
                            naves[i].setCapacidadTotal(nuevaCapacidad);
                            System.out.println("Capacidad actualizada correctamente.");
                            capacidadValida = true;
                        }
                    }
                }
            }
        }
        if (navesPasajeros == 0) {
            System.out.println("Error: No se encontró ninguna nave que admita pasajeros.");
        }
    }

    public static void mostrarTodasLasNaves(NaveEspacial[] naves) {
        int totalNaves = contarNaves(naves);
        if (totalNaves == 0) {
            System.out.println("Error: No hay naves registradas en el sistema.");
            return;
        }
        for (int i = 0; i < totalNaves; i++) {
            System.out.println(naves[i].toString());
        }
    }

    public static void eliminarNave(NaveEspacial[] naves, Scanner scanner) {
        int totalNaves = contarNaves(naves);
        if (totalNaves == 0) {
            System.out.println("Error: No hay naves registradas en el sistema.");
            return;
        }
        System.out.print("Introduce el nombre de la nave que deseas eliminar: ");
        String nombreBorrar = scanner.nextLine();
        int indiceEncontrado = buscarNave(naves, nombreBorrar);
        if (indiceEncontrado == -1) {
            System.out.println("No se encontró ninguna nave con ese nombre.");
        } else {
            for (int j = indiceEncontrado; j < totalNaves - 1; j++) {
                naves[j] = naves[j + 1];
            }
            naves[totalNaves - 1] = null;
            System.out.println("Nave eliminada correctamente.");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NaveEspacial[] naves = new NaveEspacial[50];
        int opcion;

        do {
            System.out.println("\n----- MENÚ DE MISIÓN ESPACIAL -----");
            System.out.println("1. Añadir naves espaciales");
            System.out.println("2. Mostrar naves cuya antigüedad sea superior a una dada");
            System.out.println("3. Ordenar naves por año de lanzamiento");
            System.out.println("4. Modificar capacidad total de naves que admiten pasajeros");
            System.out.println("5. Mostrar todas las naves espaciales registradas");
            System.out.println("6. Eliminar una nave espacial");
            System.out.println("7. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    anadirNaves(naves, sc);
                    break;
                case 2:
                    mostrarNavesAntiguedad(naves, sc);
                    break;
                case 3:
                    ordenarNavesPorAnio(naves);
                    break;
                case 4:
                    modificarCapacidadPasajeros(naves, sc);
                    break;
                case 5:
                    mostrarTodasLasNaves(naves);
                    break;
                case 6:
                    eliminarNave(naves, sc);
                    break;
                case 7:
                    System.out.println("¡Hasta pronto :-)! Finalizando el programa de exploración espacial.");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, introduce un número del 1 al 7.");
                    break;
            }
        } while (opcion != 7);

        sc.close();
    }
}
