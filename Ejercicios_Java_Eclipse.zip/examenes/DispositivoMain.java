package examenes;

import java.util.Scanner;

public class DispositivoMain {
    public static boolean estaVacio(Dispositivo[] aDispositivos) {
        boolean vacio = true;
        int i = 0;
        while (i < aDispositivos.length && vacio) {
            if (aDispositivos[i] != null) {
                vacio = false;
            }
            i++;
        }
        return vacio;
    }

    public static int buscarDispositivo(Dispositivo[] aDispositivos, String nombre) {
        int posicion = -1;
        boolean encontrado = false;
        int i = 0;
        while (i < aDispositivos.length && !encontrado) {
            if (aDispositivos[i] != null && aDispositivos[i].getNombre().equalsIgnoreCase(nombre)) {
                posicion = i;
                encontrado = true;
            }
            i++;
        }
        return posicion;
    }

    public static void addDispositivo(Dispositivo[] aDispositivos, Scanner sc) {
        int posLibre = -1;
        boolean encontradoLibre = false;
        int i = 0;

        while (i < aDispositivos.length && !encontradoLibre) {
            if (aDispositivos[i] == null) {
                posLibre = i;
                encontradoLibre = true;
            }
            i++;
        }

        if (posLibre == -1) {
            System.out.println("Error: Se ha alcanzado el límite máximo de 25 dispositivos.");
            return;
        }

        String nombre = "";
        boolean nombreValido = false;
        while (!nombreValido) {
            System.out.print("Nombre del dispositivo: ");
            nombre = sc.nextLine();
            if (buscarDispositivo(aDispositivos, nombre) != -1) {
                System.out.println("Ya existe un dispositivo con ese nombre. Introduce otro.");
            } else if (nombre.trim().isEmpty()) {
                System.out.println("El nombre no puede estar vacío.");
            } else {
                nombreValido = true;
            }
        }

        String tipo = "";
        boolean tipoValido = false;
        while (!tipoValido) {
            System.out.print("Tipo (movil / tablet / portatil): ");
            tipo = sc.nextLine().trim();
            if (tipo.equalsIgnoreCase("movil") || tipo.equalsIgnoreCase("tablet") || tipo.equalsIgnoreCase("portatil") ||
                tipo.equalsIgnoreCase("móvil") || tipo.equalsIgnoreCase("portátil")) {
                tipoValido = true;
            } else {
                System.out.println("Tipo no válido. Debe ser 'movil', 'tablet' o 'portatil'. Inténtalo de nuevo.");
            }
        }

        double precio = -1;
        while (precio < 0) {
            System.out.print("Precio (€): ");
            if (sc.hasNextDouble()) {
                precio = sc.nextDouble();
                if (precio < 0) {
                    System.out.println("El precio debe ser un número positivo.");
                }
            } else {
                System.out.println("Introduce un número válido.");
                sc.next();
            }
        }

        int consumo = -1;
        while (consumo < 0) {
            System.out.print("Consumo (W): ");
            if (sc.hasNextInt()) {
                consumo = sc.nextInt();
                if (consumo < 0) {
                    System.out.println("El consumo debe ser un número positivo.");
                }
            } else {
                System.out.println("Introduce un número entero válido.");
                sc.next();
            }
        }

        double peso = -1;
        while (peso < 0) {
            System.out.print("Peso (kg): ");
            if (sc.hasNextDouble()) {
                peso = sc.nextDouble();
                if (peso < 0) {
                    System.out.println("El peso debe ser un número positivo.");
                }
            } else {
                System.out.println("Introduce un número válido.");
                sc.next();
            }
        }
        sc.nextLine();

        aDispositivos[posLibre] = new Dispositivo(nombre, tipo, precio, consumo, peso);
        System.out.println("Dispositivo añadido correctamente.");
    }

    public static void mostrarEficientes(Dispositivo[] aDispositivos) {
        if (estaVacio(aDispositivos)) {
            System.out.println("Error: No hay dispositivos registrados en el sistema.");
            return;
        }
        int contador = 0;
        int i = 0;
        while (i < aDispositivos.length) {
            if (aDispositivos[i] != null && aDispositivos[i].esEficiente()) {
                System.out.println(aDispositivos[i].toString());
                contador++;
            }
            i++;
        }
        if (contador == 0) {
            System.out.println("No hay ningún dispositivo eficiente (con consumo menor a 100 W).");
        }
    }

    public static void ordenarPrecioDesc(Dispositivo[] aDispositivos) {
        if (estaVacio(aDispositivos)) {
            System.out.println("Error: No hay dispositivos registrados en el sistema.");
            return;
        }

        int total = 0;
        int i = 0;
        while (i < aDispositivos.length) {
            if (aDispositivos[i] != null) {
                total++;
            }
            i++;
        }

        Dispositivo[] auxiliar = new Dispositivo[total];
        int idx = 0;
        i = 0;
        while (i < aDispositivos.length) {
            if (aDispositivos[i] != null) {
                auxiliar[idx] = aDispositivos[i];
                idx++;
            }
            i++;
        }

        int j;
        Dispositivo aux;
        for (i = 0; i < auxiliar.length - 1; i++) {
            for (j = 0; j < auxiliar.length - 1 - i; j++) {
                if (auxiliar[j].getPrecio() < auxiliar[j + 1].getPrecio()) {
                    aux = auxiliar[j];
                    auxiliar[j] = auxiliar[j + 1];
                    auxiliar[j + 1] = aux;
                }
            }
        }

        System.out.println("Dispositivos ordenados por precio descendente:");
        for (i = 0; i < auxiliar.length; i++) {
            System.out.println(auxiliar[i].toString());
        }
    }

    public static void cambiarPrecio(Dispositivo[] aDispositivos, Scanner sc) {
        if (estaVacio(aDispositivos)) {
            System.out.println("Error: No hay dispositivos registrados en el sistema.");
            return;
        }
        System.out.print("Introduce el nombre del dispositivo a actualizar: ");
        String nombre = sc.nextLine();
        int posicion = buscarDispositivo(aDispositivos, nombre);

        if (posicion == -1) {
            System.out.println("No se encontró ningún dispositivo con ese nombre.");
        } else {
            double nuevoPrecio = -1;
            while (nuevoPrecio < 0) {
                System.out.print("Introduce el nuevo precio (€): ");
                if (sc.hasNextDouble()) {
                    nuevoPrecio = sc.nextDouble();
                    if (nuevoPrecio < 0) {
                        System.out.println("El precio debe ser un número positivo.");
                    }
                } else {
                    System.out.println("Introduce un número válido.");
                    sc.next();
                }
            }
            sc.nextLine();
            aDispositivos[posicion].setPrecio(nuevoPrecio);
            System.out.println("Precio actualizado correctamente.");
        }
    }

    public static void eliminarDispositivo(Dispositivo[] aDispositivos, Scanner sc) {
        if (estaVacio(aDispositivos)) {
            System.out.println("Error: No hay dispositivos registrados en el sistema.");
            return;
        }
        System.out.print("Introduce el nombre del dispositivo a eliminar: ");
        String nombre = sc.nextLine();
        int posicion = buscarDispositivo(aDispositivos, nombre);

        if (posicion == -1) {
            System.out.println("No se encontró ningún dispositivo con ese nombre.");
        } else {
            aDispositivos[posicion] = null;
            System.out.println("Dispositivo eliminado correctamente.");
        }
    }

    public static void mostrarDispositivos(Dispositivo[] aDispositivos) {
        if (estaVacio(aDispositivos)) {
            System.out.println("Error: No hay dispositivos registrados en el sistema.");
            return;
        }
        int i = 0;
        while (i < aDispositivos.length) {
            if (aDispositivos[i] != null) {
                System.out.println(aDispositivos[i].toString());
            }
            i++;
        }
    }

    public static void salir() {
        System.out.println("¡Hasta pronto :-)! Finalizando el programa de gestión de dispositivos.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Dispositivo[] aDispositivos = new Dispositivo[25];
        int opcion = 0;

        do {
            System.out.println("\n----- MENÚ DE GESTIÓN DE DISPOSITIVOS -----");
            System.out.println("1. Añadir un nuevo dispositivo");
            System.out.println("2. Mostrar dispositivos eficientes");
            System.out.println("3. Ordenar por precio descendente");
            System.out.println("4. Actualizar precio de un dispositivo concreto");
            System.out.println("5. Eliminar dispositivo");
            System.out.println("6. Mostrar todos los dispositivos");
            System.out.println("7. Salir del programa");
            System.out.print("Elige una opción: ");

            if (sc.hasNextInt()) {
                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {
                    case 1:
                        addDispositivo(aDispositivos, sc);
                        break;
                    case 2:
                        mostrarEficientes(aDispositivos);
                        break;
                    case 3:
                        ordenarPrecioDesc(aDispositivos);
                        break;
                    case 4:
                        cambiarPrecio(aDispositivos, sc);
                        break;
                    case 5:
                        eliminarDispositivo(aDispositivos, sc);
                        break;
                    case 6:
                        mostrarDispositivos(aDispositivos);
                        break;
                    case 7:
                        salir();
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, introduce un número del 1 al 7.");
                        break;
                }
            } else {
                System.out.println("Por favor, introduce un número entero válido.");
                sc.next();
                sc.nextLine();
            }
        } while (opcion != 7);

        sc.close();
    }
}
