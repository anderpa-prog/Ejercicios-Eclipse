package examenes;

public class Dispositivo {
    private String nombre;
    private String tipo;
    private double precio;
    private int consumo;
    private double peso;

    public Dispositivo() {
        this.nombre = "";
        this.tipo = "";
        this.precio = 0.0;
        this.consumo = 0;
        this.peso = 0.0;
    }

    public Dispositivo(String nombre, String tipo, double precio, int consumo, double peso) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.consumo = consumo;
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getConsumo() {
        return consumo;
    }

    public void setConsumo(int consumo) {
        this.consumo = consumo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public boolean esEficiente() {
        return this.consumo < 100;
    }

    public double indicePortabilidad() {
        return (this.consumo / 10.0) + (this.peso * 2.0);
    }

    @Override
    public String toString() {
        return "Dispositivo{nombre='" + nombre + "', tipo='" + tipo + "', precio=" + precio +
               ", consumo=" + consumo + ", peso=" + peso + ", eficiente=" + esEficiente() +
               ", indicePortabilidad=" + indicePortabilidad() + "}";
    }
}
