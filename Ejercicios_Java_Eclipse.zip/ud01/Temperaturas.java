package ud01;

import java.util.Scanner;

public class Temperaturas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double celsius;

        System.out.print("Introduce la temperatura en grados Celsius: ");
        celsius = sc.nextDouble();

        System.out.println("Fahrenheit: " + (celsius * 1.8 + 32) + " °F");
        System.out.println("Kelvin: " + (celsius + 273.15) + " K");

        sc.close();
    }
}
