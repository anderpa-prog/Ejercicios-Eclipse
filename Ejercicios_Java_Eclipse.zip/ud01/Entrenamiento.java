package ud01;

import java.util.Scanner;

public class Entrenamiento {
    public static void main(String[] args) {
        int numEntrenamientos, durEntrenamientos, durEntMes;
        double peso, altura;
        Scanner sc = new Scanner(System.in);

        System.out.println("Hola usuari@, vamos a calcular algunos de tus datos, introduce tu peso en kg: ");
        peso = sc.nextDouble();
        System.out.println("Introduce tu altura en metros: ");
        altura = sc.nextDouble();
        System.out.println("Introduce el número de entrenamientos que realizas en el mes: ");
        numEntrenamientos = sc.nextInt();
        System.out.println("Introduce la duración media de tus entrenamientos en minutos:");
        durEntrenamientos = sc.nextInt();

        durEntMes = numEntrenamientos * durEntrenamientos;

        System.out.println("Tu IMC (Índice de Masa Corporal) es de: " + (peso / (altura * altura)));
        System.out.println("Tu número de minutos entrenados durante el mes son: " + durEntMes + " minutos");
        System.out.println("Tu número total de horas entrenadas durante el mes: " + (durEntMes / 60.0) + " horas");
        System.out.println("Tu tiempo medio entrenando es de: " + ((durEntMes / 60.0) / 4.0) + " horas semanales");

        sc.close();
    }
}
