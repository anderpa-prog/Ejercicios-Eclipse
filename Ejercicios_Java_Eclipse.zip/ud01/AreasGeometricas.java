package ud01;

import java.util.Scanner;

public class AreasGeometricas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nombre;
        final double PI = 3.14;
        double radio, ladocuadrado, ladolargo, ladocorto, altura, base;

        System.out.println("¡Hola!");
        System.out.println("¿Cuál es tu nombre?");
        nombre = sc.next();
        System.out.print("Bienvenid@ " + nombre + ". ");
        System.out.println("Vamos a realizar diferentes cálculos.");
        System.out.println("*********************************");

        System.out.println("CÍRCULO");
        System.out.print("Introduce el valor del radio: ");
        radio = sc.nextDouble();
        System.out.println("El área del círculo es " + (PI * radio * radio) + " m2.");
        System.out.println("*********************************");

        System.out.println("CUADRADO");
        System.out.print("Introduce el valor del lado: ");
        ladocuadrado = sc.nextDouble();
        System.out.println("El área del cuadrado es " + (ladocuadrado * ladocuadrado) + " m2.");
        System.out.println("*********************************");

        System.out.println("RECTÁNGULO");
        System.out.print("Introduce el valor del lado más largo: ");
        ladolargo = sc.nextDouble();
        System.out.print("Introduce el valor del lado más corto: ");
        ladocorto = sc.nextDouble();
        System.out.println("El área del rectángulo es " + (ladolargo * ladocorto) + " m2.");
        System.out.println("*********************************");

        System.out.println("TRIÁNGULO");
        System.out.print("Introduce el valor de la altura: ");
        altura = sc.nextDouble();
        System.out.print("Introduce el valor de la base: ");
        base = sc.nextDouble();
        System.out.println("El área del triángulo es " + (altura * base) / 2 + " m2.");

        sc.close();
    }
}
