package ud02;

import java.util.Scanner;

public class Ej117Sumapadw {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero, suma = 0, i = 0, sumaAnterior = 0;

        System.out.print("Introduce un número entero: ");
        numero = sc.nextInt();
        i = numero;

        if (numero >= 0) {
            if (i % 2 != 0) {
                i--;
            }
            while (i >= 0) {
                sumaAnterior = suma;
                suma += i;
                System.out.println(sumaAnterior + " + " + i + " = " + suma);
                i -= 2;
            }
        } else {
            if (i % 2 != 0) {
                i++;
            }
            while (i <= 0) {
                sumaAnterior = suma;
                suma += i;
                System.out.println(sumaAnterior + " + " + i + " = " + suma);
                i += 2;
            }
        }

        System.out.println("La suma de los pares desde " + numero + " hasta 0 es: " + suma);
        sc.close();
    }
}
