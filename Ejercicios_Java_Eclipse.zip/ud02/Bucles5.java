package ud02;

import java.util.Scanner;

public class Bucles5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String numero;

        System.out.print("Introduce un número para saber cuántos dígitos tiene: ");
        numero = sc.next();

        System.out.println("El número tiene: " + numero.length() + " dígitos");
        sc.close();
    }
}
