package ud02;

import java.util.Scanner;

public class Bucles4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero, i = 1, factorial = 1;

        System.out.println("FACTORIAL DE UN NÚMERO");
        System.out.println("Dime un número que sea mayor que cero:");
        numero = sc.nextInt();

        while (numero <= 0) {
            System.out.print("Error. El número debe ser mayor que 0: ");
            numero = sc.nextInt();
        }

        while (i <= numero) {
            factorial = factorial * i;
            i++;
        }

        System.out.println("El factorial de " + numero + " es: " + factorial);
        sc.close();
    }
}
