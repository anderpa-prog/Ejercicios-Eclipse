package ud02;

import java.util.Scanner;

public class Permiso {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int edad;

        System.out.print("Introduce tu edad: ");
        edad = sc.nextInt();

        if (edad == 18) {
            System.out.println("Justo de edad");
        } else if (edad > 18) {
            System.out.println("Puedes entrar");
        } else {
            System.out.println("No puedes entrar");
        }

        sc.close();
    }
}
