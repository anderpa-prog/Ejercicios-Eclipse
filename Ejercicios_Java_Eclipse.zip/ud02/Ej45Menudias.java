package ud02;

import java.util.Scanner;

public class Ej45Menudias {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char letra;

        System.out.println("DÍAS DE LA SEMANA");
        System.out.print("Introduce una letra (L, M, X, J, V, S, D): ");
        letra = sc.next().toUpperCase().charAt(0);

        switch (letra) {
            case 'L':
                System.out.println("Lunes");
                break;
            case 'M':
                System.out.println("Martes");
                break;
            case 'X':
                System.out.println("Miércoles");
                break;
            case 'J':
                System.out.println("Jueves");
                break;
            case 'V':
                System.out.println("Viernes");
                break;
            case 'S':
                System.out.println("Sábado");
                break;
            case 'D':
                System.out.println("Domingo");
                break;
            default:
                System.out.println("ERROR");
                break;
        }

        sc.close();
    }
}
