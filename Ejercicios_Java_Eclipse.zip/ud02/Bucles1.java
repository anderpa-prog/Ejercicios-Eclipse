package ud02;

public class Bucles1 {
    public static void main(String[] args) {
        int i = 5;
        while (i < 15) {
            System.out.println(i);
            i++;
        }
    }
}
