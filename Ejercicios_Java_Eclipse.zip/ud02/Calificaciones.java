package ud02;

import java.util.Scanner;

public class Calificaciones {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double nota;

        System.out.print("Introduce una nota entre 0 y 10: ");
        nota = sc.nextDouble();

        while (nota < 0 || nota > 10) {
            System.out.println("Error: La nota debe estar entre 0 y 10.");
            nota = sc.nextDouble();
        }

        if (nota < 5) {
            System.out.println("Suspenso");
        } else if (nota < 7) {
            System.out.println("Aprobado");
        } else if (nota < 9) {
            System.out.println("Notable");
        } else {
            System.out.println("Sobresaliente");
        }

        sc.close();
    }
}
