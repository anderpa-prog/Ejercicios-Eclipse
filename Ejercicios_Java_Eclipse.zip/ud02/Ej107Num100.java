package ud02;

public class Ej107Num100 {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 100) {
            System.out.print(i);
            if (i < 100) {
                System.out.print(", ");
            }
            i++;
        }
    }
}
