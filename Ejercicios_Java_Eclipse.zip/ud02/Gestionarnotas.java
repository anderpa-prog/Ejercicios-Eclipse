package ud02;

import java.util.Scanner;

public class Gestionarnotas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String user, password;
        int opcion;
        double ex1, ex2, ex3, ultimoEx, trabajo, mediaParciales, notaFinal;

        System.out.print("Introduce tu usuario: ");
        user = sc.nextLine();
        System.out.print("Introduce tu contraseña: ");
        password = sc.nextLine();

        while (password.toLowerCase().indexOf('e') != -1) {
            System.out.println("ERROR, en la contraseña no puede aparecer la letra e. Introduce de nuevo, por favor:");
            System.out.print("Introduce tu usuario: ");
            user = sc.nextLine();
            System.out.print("Introduce tu contraseña: ");
            password = sc.nextLine();
        }

        do {
            System.out.println("\nMENU");
            System.out.println("1.- Introducir notas");
            System.out.println("2.- Salir del programa");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Introduce el nombre y apellido del alumno: ");
                    String alumno = sc.nextLine();

                    System.out.print("Introduce la nota del primer examen: ");
                    ex1 = sc.nextDouble();
                    while (ex1 < 0 || ex1 > 10) {
                        System.out.println("ERROR! La nota no puede ser negativa ni mayor de 10.");
                        System.out.print("Introduce la nota del primer examen: ");
                        ex1 = sc.nextDouble();
                    }

                    System.out.print("Introduce la nota del segundo examen: ");
                    ex2 = sc.nextDouble();
                    while (ex2 < 0 || ex2 > 10) {
                        System.out.println("ERROR! La nota no puede ser negativa ni mayor de 10.");
                        System.out.print("Introduce la nota del segundo examen: ");
                        ex2 = sc.nextDouble();
                    }

                    System.out.print("Introduce la nota del tercer examen: ");
                    ex3 = sc.nextDouble();
                    while (ex3 < 0 || ex3 > 10) {
                        System.out.println("ERROR! La nota no puede ser negativa ni mayor de 10.");
                        System.out.print("Introduce la nota del tercer examen: ");
                        ex3 = sc.nextDouble();
                    }

                    System.out.print("Introduce la nota del último examen: ");
                    ultimoEx = sc.nextDouble();
                    while (ultimoEx < 0 || ultimoEx > 10) {
                        System.out.println("ERROR! La nota no puede ser negativa ni mayor de 10.");
                        System.out.print("Introduce la nota del último examen: ");
                        ultimoEx = sc.nextDouble();
                    }

                    System.out.print("Introduce la nota del trabajo final: ");
                    trabajo = sc.nextDouble();
                    while (trabajo < 0 || trabajo > 10) {
                        System.out.println("ERROR! La nota no puede ser negativa ni mayor de 10.");
                        System.out.print("Introduce la nota del trabajo final: ");
                        trabajo = sc.nextDouble();
                    }

                    mediaParciales = (ex1 + ex2 + ex3) / 3.0;
                    notaFinal = (mediaParciales * 0.55) + (ultimoEx * 0.30) + (trabajo * 0.15);

                    String calificacion = "";
                    if (notaFinal >= 0 && notaFinal < 5) {
                        calificacion = "Suspenso";
                    } else if (notaFinal >= 5 && notaFinal < 6) {
                        calificacion = "Suficiente";
                    } else if (notaFinal >= 6 && notaFinal < 7) {
                        calificacion = "Bien";
                    } else if (notaFinal >= 7 && notaFinal < 9) {
                        calificacion = "Notable";
                    } else if (notaFinal >= 9 && notaFinal <= 10) {
                        calificacion = "Sobresaliente";
                    }

                    System.out.println("----------------------------------------");
                    System.out.println("La nota final del alumno " + alumno + " (usuario: " + user + ") es: " + notaFinal + ", " + calificacion);
                    System.out.println("----------------------------------------");
                    break;
                case 2:
                    System.out.println("Muchas gracias y hasta pronto.");
                    break;
                default:
                    System.out.println("ERROR: Opción no válida. Introduce 1 o 2.");
                    break;
            }
        } while (opcion != 2);

        sc.close();
    }
}
