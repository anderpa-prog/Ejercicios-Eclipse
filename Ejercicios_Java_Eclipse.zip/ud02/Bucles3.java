package ud02;

public class Bucles3 {
    public static void main(String[] args) {
        for (int i = 2; i <= 10; i += 2) {
            System.out.print(i + " ");
        }
    }
}
