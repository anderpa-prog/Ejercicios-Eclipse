package ud02;

import java.util.Scanner;

public class MenuString {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nombre = "", palabra1 = "", palabra2 = "";
        int opcion = 0;
        String invertida = "", resultado = "", formato = "", palabraModificada = "";
        int i = 0, repeticiones = 0;

        System.out.print("Introduce tu nombre: ");
        nombre = sc.nextLine();
        System.out.println("Bienvenid@ " + nombre + ". ¿Qué quieres hacer?");

        do {
            System.out.println("\nMENÚ PRINCIPAL");
            System.out.println("1.- Dar la vuelta a una palabra.");
            System.out.println("2.- Comparar dos palabras.");
            System.out.println("3.- Número de letras.");
            System.out.println("4.- Repetir palabra.");
            System.out.println("5.- Repetir palabra (Mayúscula / Minúscula).");
            System.out.println("6.- Salir del programa");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Introduce una palabra para darle la vuelta: ");
                    palabra1 = sc.nextLine();
                    invertida = "";
                    i = palabra1.length() - 1;
                    while (i >= 0) {
                        invertida = invertida + palabra1.charAt(i);
                        i--;
                    }
                    System.out.println("Palabra invertida: " + invertida);
                    break;
                case 2:
                    System.out.print("Inserta la primera palabra: ");
                    palabra1 = sc.nextLine();
                    System.out.print("Inserta la segunda palabra: ");
                    palabra2 = sc.nextLine();
                    if (palabra1.equalsIgnoreCase(palabra2)) {
                        System.out.println("Son iguales");
                    } else {
                        System.out.println("No son iguales");
                    }
                    break;
                case 3:
                    System.out.print("Inserta una palabra: ");
                    palabra1 = sc.nextLine();
                    System.out.println("Número de letras: " + palabra1.length());
                    if (palabra1.length() >= 7) {
                        System.out.println("El tamaño de la palabra es grande.");
                    } else {
                        System.out.println("El tamaño de la palabra es pequeño.");
                    }
                    break;
                case 4:
                    System.out.print("Inserta la palabra que quieras repetir: ");
                    palabra1 = sc.nextLine();
                    System.out.print("¿Cuántas veces la quieres repetir?: ");
                    repeticiones = sc.nextInt();
                    sc.nextLine();
                    resultado = "";
                    for (i = 1; i <= repeticiones; i++) {
                        resultado += palabra1.toUpperCase();
                        if (i < repeticiones) {
                            resultado += " ";
                        }
                    }
                    System.out.println(resultado);
                    break;
                case 5:
                    System.out.print("Inserta la palabra que quieres repetir: ");
                    palabra1 = sc.nextLine();
                    System.out.print("¿Mayúscula o Minúscula?: ");
                    formato = sc.nextLine().trim();
                    System.out.print("¿Cuántas veces la quieres repetir?: ");
                    repeticiones = sc.nextInt();
                    sc.nextLine();

                    while (repeticiones >= 6) {
                        System.out.println("No se puede repetir 6 veces o más.");
                        System.out.print("¿Cuántas veces la quieres repetir?: ");
                        repeticiones = sc.nextInt();
                        sc.nextLine();
                    }

                    if (formato.equalsIgnoreCase("mayuscula") || formato.equalsIgnoreCase("mayúsculas") || formato.equalsIgnoreCase("mayúscula")) {
                        palabraModificada = palabra1.toUpperCase();
                    } else {
                        palabraModificada = palabra1.toLowerCase();
                    }

                    resultado = "";
                    for (i = 1; i <= repeticiones; i++) {
                        resultado += palabraModificada;
                        if (i < repeticiones) {
                            resultado += " ";
                        }
                    }
                    System.out.println(resultado);
                    break;
                case 6:
                    System.out.println("Muchas gracias y hasta pronto.");
                    break;
                default:
                    System.out.println("Error: Opción no válida.");
                    break;
            }
        } while (opcion != 6);

        sc.close();
    }
}
