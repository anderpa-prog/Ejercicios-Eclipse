package ud02;

public class Bucles3ver2 {
    public static void main(String[] args) {
        int i = 0, numPar = 0;
        for (i = 1; i <= 5; i++) {
            numPar = i * 2;
            System.out.print(numPar + " ");
        }
    }
}
