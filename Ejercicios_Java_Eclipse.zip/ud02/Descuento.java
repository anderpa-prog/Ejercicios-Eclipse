package ud02;

import java.util.Scanner;

public class Descuento {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double importe, descuento;

        System.out.print("Introduce el importe de la compra en €: ");
        importe = sc.nextDouble();

        while (importe < 0) {
            System.out.print("Error. El importe no puede ser negativo. Introduce un importe válido: ");
            importe = sc.nextDouble();
        }

        if (importe > 50) {
            descuento = importe * 0.10;
            System.out.println("--- DETALLES DE LA COMPRA ---");
            System.out.println("Precio original: " + importe + " €");
            System.out.println("Descuento aplicado (10%): " + descuento + " €");
            System.out.println("Precio final a pagar: " + (importe - descuento) + " €");
        } else {
            System.out.println("No tiene descuento.");
            System.out.println("Precio final a pagar: " + importe + " €");
        }

        sc.close();
    }
}
