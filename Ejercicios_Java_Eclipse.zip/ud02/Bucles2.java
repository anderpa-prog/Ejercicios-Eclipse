package ud02;

public class Bucles2 {
    public static void main(String[] args) {
        for (int num = 200; num <= 300; num++) {
            System.out.print(num);
            if (num < 300) {
                System.out.print(", ");
            }
        }
    }
}
