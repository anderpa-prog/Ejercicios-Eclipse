package ud02;

import java.util.Scanner;

public class Bucles5ver2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero, numOriginal;
        int i = 0;

        System.out.print("Introduce un número para saber cuántos dígitos tiene: ");
        numero = sc.nextInt();
        numOriginal = numero;

        if (numero == 0) {
            i = 1;
        } else {
            while (numero > 0) {
                numero = numero / 10;
                i++;
            }
        }

        System.out.println("El número " + numOriginal + " tiene: " + i + " dígitos.");
        sc.close();
    }
}
