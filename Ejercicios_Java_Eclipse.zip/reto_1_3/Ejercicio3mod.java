package reto_1_3;

import java.util.Scanner;

public class Ejercicio3mod {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int diaAct, mesAct, anioAct;
        int necesitanRev = 0, noNecesitanRev = 0, totalBicis = 0;
        int menos6Meses = 0, mas2Anios = 0;
        char continuar;

        System.out.println("=== FECHA ACTUAL ===");
        System.out.print("Día: ");
        diaAct = sc.nextInt();
        System.out.print("Mes: ");
        mesAct = sc.nextInt();
        System.out.print("Año: ");
        anioAct = sc.nextInt();

        int diasActual = anioAct * 365 + mesAct * 30 + diaAct;

        do {
            totalBicis++;
            System.out.print("\nIntroduce el número de identificación de la bicicleta: ");
            int idBici = sc.nextInt();

            System.out.println("Fecha de la última revisión de la bici " + idBici + ":");
            System.out.print("Día: ");
            int diaRev = sc.nextInt();
            System.out.print("Mes: ");
            int mesRev = sc.nextInt();
            System.out.print("Año: ");
            int anioRev = sc.nextInt();

            int diasRev = anioRev * 365 + mesRev * 30 + diaRev;
            int diferenciaDias = diasActual - diasRev;

            if (diferenciaDias > 365) {
                System.out.println("Esta bicicleta necesita revisión.");
                necesitanRev++;
            } else {
                System.out.println("Esta bicicleta NO necesita revisión.");
                noNecesitanRev++;
            }

            if (diferenciaDias < 180) {
                menos6Meses++;
            }
            if (diferenciaDias > 730) {
                mas2Anios++;
            }

            System.out.print("¿Quiere registrar otra bicicleta? Conteste S o N: ");
            continuar = sc.next().toUpperCase().charAt(0);
        } while (continuar == 'S');

        System.out.println("\n=== RESUMEN DE FLOTA ===");
        System.out.println("Bicicletas que necesitan revisión: " + necesitanRev);
        System.out.println("Bicicletas que no necesitan revisión: " + noNecesitanRev);
        System.out.println("Total de bicicletas registradas: " + totalBicis);
        System.out.printf("Porcentaje que necesitan revisión: %.2f%%\n", (necesitanRev * 100.0) / totalBicis);
        System.out.printf("Porcentaje que no necesitan revisión: %.2f%%\n", (noNecesitanRev * 100.0) / totalBicis);
        System.out.println("Bicicletas revisadas hace menos de 6 meses: " + menos6Meses);
        System.out.println("Bicicletas revisadas hace más de 2 años: " + mas2Anios);

        sc.close();
    }
}
