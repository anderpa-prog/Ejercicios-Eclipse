package reto_1_3;

import java.util.Scanner;

public class Ejercicio5mod {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numUsuarios;
        int maxMinutosUsuario = -1, usuarioMaxMinutos = 0;
        double maxMediaDiaria = -1;
        int usuarioMaxMedia = 0;
        int totalMinutosTodos = 0, totalDiasTodos = 0, usuariosObjetivo = 0;

        System.out.print("¿Cuántos usuarios se van a registrar?: ");
        numUsuarios = sc.nextInt();

        for (int u = 1; u <= numUsuarios; u++) {
            System.out.println("\n--- Usuario " + u + " ---");
            System.out.print("Número de días que ha acudido esta semana: ");
            int dias = sc.nextInt();

            int minutosUsuario = 0, diasMas60 = 0;
            for (int d = 1; d <= dias; d++) {
                System.out.print("Minutos realizados el día " + d + ": ");
                int mins = sc.nextInt();
                minutosUsuario += mins;
                if (mins > 60) {
                    diasMas60++;
                }
            }

            double mediaUsuario = dias > 0 ? (double) minutosUsuario / dias : 0;
            System.out.println("Total minutos en la semana: " + minutosUsuario);
            System.out.printf("Media de minutos por día: %.2f\n", mediaUsuario);
            System.out.println("Días con más de 60 minutos: " + diasMas60);

            if (minutosUsuario > 300) {
                System.out.println("¡Ha alcanzado el objetivo semanal!");
                usuariosObjetivo++;
            }

            if (minutosUsuario > maxMinutosUsuario) {
                maxMinutosUsuario = minutosUsuario;
                usuarioMaxMinutos = u;
            }
            if (mediaUsuario > maxMediaDiaria) {
                maxMediaDiaria = mediaUsuario;
                usuarioMaxMedia = u;
            }

            totalMinutosTodos += minutosUsuario;
            totalDiasTodos += dias;
        }

        System.out.println("\n=== RESUMEN GIMNASIO ===");
        System.out.println("Usuario con más minutos: Usuario " + usuarioMaxMinutos + " (" + maxMinutosUsuario + " min)");
        System.out.println("Total de minutos entre todos: " + totalMinutosTodos);
        System.out.println("Total de días entrenados: " + totalDiasTodos);
        if (numUsuarios > 0) {
            System.out.printf("Media de minutos entre todos los usuarios: %.2f\n", (double) totalMinutosTodos / numUsuarios);
        }
        System.out.printf("Usuario con mayor media diaria: Usuario %d (%.2f min/día)\n", usuarioMaxMedia, maxMediaDiaria);
        System.out.println("Usuarios que alcanzaron el objetivo semanal (>300 min): " + usuariosObjetivo);

        sc.close();
    }
}
