package reto_1_3;

import java.util.Scanner;

public class Ejercicio6mod {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numJugadores;
        int maxPuntos = -1, jugadorMaxPuntos = 0;
        int maxEnemigos = -1, jugadorMaxEnemigos = 0;
        int puntosTotalesGrupo = 0, enemigosTotalesGrupo = 0;
        int totalPartidasGrupo = 0, totalPartidasBonus = 0;

        System.out.print("¿Cuántos jugadores se van a registrar?: ");
        numJugadores = sc.nextInt();

        for (int j = 1; j <= numJugadores; j++) {
            System.out.println("\n--- Jugador " + j + " ---");
            System.out.print("Número de partidas jugadas: ");
            int partidas = sc.nextInt();

            int puntosJugador = 0, enemigosJugador = 0;
            for (int p = 1; p <= partidas; p++) {
                System.out.print("Puntos partida " + p + ": ");
                int pts = sc.nextInt();
                System.out.print("Enemigos derrotados partida " + p + ": ");
                int enem = sc.nextInt();

                if (pts > 1000) {
                    pts += 100;
                    totalPartidasBonus++;
                }

                puntosJugador += pts;
                enemigosJugador += enem;
            }

            double mediaPuntos = partidas > 0 ? (double) puntosJugador / partidas : 0;
            System.out.println("Puntuación total (con bonus): " + puntosJugador);
            System.out.println("Enemigos derrotados: " + enemigosJugador);
            System.out.printf("Puntuación media por partida: %.2f\n", mediaPuntos);

            if (puntosJugador > maxPuntos) {
                maxPuntos = puntosJugador;
                jugadorMaxPuntos = j;
            }
            if (enemigosJugador > maxEnemigos) {
                maxEnemigos = enemigosJugador;
                jugadorMaxEnemigos = j;
            }

            puntosTotalesGrupo += puntosJugador;
            enemigosTotalesGrupo += enemigosJugador;
            totalPartidasGrupo += partidas;
        }

        System.out.println("\n=== RESUMEN VIDEOJUEGO ===");
        System.out.println("Jugador con mayor puntuación: Jugador " + jugadorMaxPuntos + " (" + maxPuntos + " pts)");
        System.out.println("Puntuación total entre todos: " + puntosTotalesGrupo);
        System.out.println("Número total de enemigos derrotados: " + enemigosTotalesGrupo);
        if (numJugadores > 0) {
            System.out.printf("Puntuación media de todos los jugadores: %.2f\n", (double) puntosTotalesGrupo / numJugadores);
        }
        System.out.println("Jugador que derrotó a más enemigos: Jugador " + jugadorMaxEnemigos + " (" + maxEnemigos + ")");
        System.out.println("Total de partidas jugadas: " + totalPartidasGrupo);
        System.out.println("Partidas que obtuvieron el bonus de 100 pts: " + totalPartidasBonus);

        sc.close();
    }
}
