package reto_1_3;

import java.util.Scanner;

public class Ejercicio1mod {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numPersonas;
        double totalGrupo = 0;

        System.out.print("¿Cuántas personas se van a registrar?: ");
        numPersonas = sc.nextInt();
        while (numPersonas <= 0) {
            System.out.print("Error. Introduce un número mayor que 0: ");
            numPersonas = sc.nextInt();
        }

        for (int p = 1; p <= numPersonas; p++) {
            double totalPersonaSemana = 0;
            System.out.println("\n=== REGISTRO SEMANAL PERSONA " + p + " ===");

            for (int dia = 1; dia <= 7; dia++) {
                int opcion;
                System.out.println("\n--- Día " + dia + " ---");
                do {
                    System.out.println("1. Transporte en coche (0,21 kg CO2/km)");
                    System.out.println("2. Transporte en autobús (0,10 kg CO2/km)");
                    System.out.println("3. Transporte en bicicleta (0 kg CO2/km)");
                    System.out.println("4. Uso de plancha (0,70 kg CO2/h)");
                    System.out.println("5. Uso del ordenador (0,08 kg CO2/h)");
                    System.out.println("6. Uso del móvil (0,02 kg CO2/h)");
                    System.out.println("7. Finalizar actividades del día");
                    System.out.print("Elige una opción: ");
                    opcion = sc.nextInt();

                    switch (opcion) {
                        case 1:
                            System.out.print("¿Cuántos km recorriste en coche?: ");
                            double kmCoche = sc.nextDouble();
                            while (kmCoche < 0) {
                                System.out.print("Error. Valor no válido, introduce km >= 0: ");
                                kmCoche = sc.nextDouble();
                            }
                            totalPersonaSemana += kmCoche * 0.21;
                            break;
                        case 2:
                            System.out.print("¿Cuántos km recorriste en autobús?: ");
                            double kmBus = sc.nextDouble();
                            while (kmBus < 0) {
                                System.out.print("Error. Valor no válido, introduce km >= 0: ");
                                kmBus = sc.nextDouble();
                            }
                            totalPersonaSemana += kmBus * 0.10;
                            break;
                        case 3:
                            System.out.print("¿Cuántos km recorriste en bicicleta?: ");
                            double kmBici = sc.nextDouble();
                            while (kmBici < 0) {
                                System.out.print("Error. Valor no válido, introduce km >= 0: ");
                                kmBici = sc.nextDouble();
                            }
                            break;
                        case 4:
                            System.out.print("¿Usaste la plancha? (1=sí, 0=no): ");
                            int usoPlancha = sc.nextInt();
                            while (usoPlancha != 0 && usoPlancha != 1) {
                                System.out.print("Error. Introduce 1 para sí o 0 para no: ");
                                usoPlancha = sc.nextInt();
                            }
                            if (usoPlancha == 1) {
                                System.out.print("¿Cuántas horas la utilizaste?: ");
                                double hPlancha = sc.nextDouble();
                                while (hPlancha < 0) {
                                    System.out.print("Error. Introduce horas >= 0: ");
                                    hPlancha = sc.nextDouble();
                                }
                                totalPersonaSemana += hPlancha * 0.70;
                            }
                            break;
                        case 5:
                            System.out.print("¿Cuántas horas utilizaste el ordenador?: ");
                            double hOrdenador = sc.nextDouble();
                            while (hOrdenador < 0) {
                                System.out.print("Error. Introduce horas >= 0: ");
                                hOrdenador = sc.nextDouble();
                            }
                            totalPersonaSemana += hOrdenador * 0.08;
                            break;
                        case 6:
                            System.out.print("¿Cuántas horas utilizaste el móvil?: ");
                            double hMovil = sc.nextDouble();
                            while (hMovil < 0) {
                                System.out.print("Error. Introduce horas >= 0: ");
                                hMovil = sc.nextDouble();
                            }
                            totalPersonaSemana += hMovil * 0.02;
                            break;
                        case 7:
                            System.out.println("Día " + dia + " finalizado.");
                            break;
                        default:
                            System.out.println("Error: Opción incorrecta.");
                            break;
                    }
                } while (opcion != 7);
            }

            System.out.printf("\nTotal CO2 semanal Persona %d: %.2f kg\n", p, totalPersonaSemana);
            if (totalPersonaSemana < 10) {
                System.out.println("Excelente, tu huella de carbono es muy baja");
            } else if (totalPersonaSemana <= 30) {
                System.out.println("Tu huella de carbono es moderada, puedes mejorar");
            } else {
                System.out.println("Atención, tu huella de carbono es muy alta");
            }

            totalGrupo += totalPersonaSemana;
        }

        System.out.printf("\nTotal de CO2 emitido por el grupo completo: %.2f kg\n", totalGrupo);
        sc.close();
    }
}
