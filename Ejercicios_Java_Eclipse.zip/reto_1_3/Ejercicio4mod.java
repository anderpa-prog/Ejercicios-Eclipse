package reto_1_3;

import java.util.Scanner;

public class Ejercicio4mod {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numClientes;
        double totalRecaudado = 0;
        int totalAdultos = 0, totalInfantiles = 0;
        int maxEntradas = -1, clienteMax = 0;

        System.out.print("¿Cuántos clientes se van a registrar?: ");
        numClientes = sc.nextInt();

        for (int c = 1; c <= numClientes; c++) {
            System.out.println("\n--- Cliente " + c + " ---");
            System.out.print("Entradas de adulto (9€): ");
            int adultos = sc.nextInt();
            System.out.print("Entradas infantiles (6€): ");
            int infantiles = sc.nextInt();

            int totalEntradasCliente = adultos + infantiles;
            double precio = (adultos * 9.0) + (infantiles * 6.0);
            if (totalEntradasCliente >= 5) {
                precio *= 0.90;
            }

            System.out.println("Entradas adulto: " + adultos);
            System.out.println("Entradas infantiles: " + infantiles);
            System.out.println("Total entradas: " + totalEntradasCliente);
            System.out.printf("Precio a pagar: %.2f €\n", precio);

            totalRecaudado += precio;
            totalAdultos += adultos;
            totalInfantiles += infantiles;

            if (totalEntradasCliente > maxEntradas) {
                maxEntradas = totalEntradasCliente;
                clienteMax = c;
            }
        }

        int totalVendidas = totalAdultos + totalInfantiles;
        System.out.println("\n=== RESUMEN DE SESIÓN ===");
        System.out.printf("Dinero total recaudado: %.2f €\n", totalRecaudado);
        System.out.println("Total entradas adulto: " + totalAdultos);
        System.out.println("Total entradas infantiles: " + totalInfantiles);
        System.out.println("Cliente que compró más entradas: Cliente " + clienteMax + " (" + maxEntradas + " entradas)");
        System.out.println("Total entradas vendidas: " + totalVendidas);
        if (numClientes > 0) {
            System.out.printf("Precio medio pagado por cliente: %.2f €\n", totalRecaudado / numClientes);
        }
        if (totalAdultos > totalInfantiles) {
            System.out.println("Tipo de entrada más vendida: Adulto");
        } else if (totalInfantiles > totalAdultos) {
            System.out.println("Tipo de entrada más vendida: Infantil");
        } else {
            System.out.println("Se vendieron las mismas entradas de adulto que infantiles.");
        }

        sc.close();
    }
}
