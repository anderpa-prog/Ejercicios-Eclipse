package ud04;

public class Coche {
    public String material;
    public String color;
    public String direccion;
    public int ruedas;
    public int volante;
    public int pasajeros;

    public void moverHaciaDelante() {
        this.direccion = "Hacia Delante";
    }

    public void moverHaciaAtras() {
        this.direccion = "Hacia Atras";
    }

    public void cambiarColor(String c) {
        this.color = c;
    }

    public void quitarRueda() {
        this.ruedas--;
    }

    public boolean estaLleno() {
        if (this.pasajeros >= 5) {
            return true;
        } else {
            return false;
        }
    }
}
