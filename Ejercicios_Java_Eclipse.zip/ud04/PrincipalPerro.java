package ud04;

public class PrincipalPerro {
    public static void main(String[] args) {
        Perro p1 = new Perro();
        System.out.println("Perro 1 " + p1);

        Perro p2 = new Perro("Pug", "Crema", true, 21);
        System.out.println("Es PPP: " + p2.esPpp());
        System.out.println("Perro 1 " + p2);

        Perro p3 = new Perro("Labrador Retriever", "Negro", false, 19);
        System.out.println("Perro 2 " + p3);

        Perro p4 = new Perro("Border Collie");
        System.out.println("Perro 3 " + p4);
        p4.setColor("Blanco y Negro");
        System.out.println("Perro 3 " + p4.getColor());

        Perro p6 = new Perro();
        System.out.println("Perro 6 " + p6);
    }
}
