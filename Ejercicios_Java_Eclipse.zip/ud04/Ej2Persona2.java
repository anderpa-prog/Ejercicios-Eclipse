package ud04;

public class Ej2Persona2 {
    private String nombre;
    private int edad;
    private String dni;

    public Ej2Persona2() {
        this.nombre = "";
        this.edad = 0;
        this.dni = "";
    }

    public Ej2Persona2(String nombre, int edad, String dni) {
        this.nombre = nombre;
        this.edad = edad;
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Ej2Persona2 [nombre=" + nombre + ", edad=" + edad + ", dni=" + dni + "]";
    }

    public void mostrar() {
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Edad: " + this.edad);
        System.out.println("DNI: " + this.dni);
    }

    public boolean esMayorDeEdad() {
        if (this.edad < 18) {
            return false;
        } else {
            return true;
        }
    }
}
