package ud04;

public class Ej3Libro {
    private String titulo;
    private String autor;
    private int numPag;

    public Ej3Libro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
        this.numPag = 0;
    }

    public Ej3Libro(String titulo, String autor, int numPag) {
        this.titulo = titulo;
        this.autor = autor;
        if (numPag < 0) {
            this.numPag = 0;
        } else {
            this.numPag = numPag;
        }
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNumPag() {
        return numPag;
    }

    public void setNumPag(int numPag) {
        this.numPag = numPag;
    }

    @Override
    public String toString() {
        return "Libro [titulo=" + titulo + ", autor=" + autor + ", numPag=" + numPag + "]";
    }

    public boolean esLargo() {
        if (this.numPag > 300) {
            return true;
        } else {
            return false;
        }
    }

    public void mostrarInformacion() {
        System.out.println("Título: " + this.titulo);
        System.out.println("Autor: " + this.autor);
        System.out.println("Nº de páginas: " + this.numPag);
    }
}
