package ud04;

public class Persona {
    private String nombre;
    private int edad;

    public Persona() {
        this.nombre = "";
        this.edad = 0;
    }

    public Persona(String n, int e) {
        this.nombre = n;
        this.edad = e;
    }

    public Persona(int e) {
        this.nombre = "";
        this.edad = e;
    }

    public Persona(String n) {
        this.nombre = n;
        this.edad = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
