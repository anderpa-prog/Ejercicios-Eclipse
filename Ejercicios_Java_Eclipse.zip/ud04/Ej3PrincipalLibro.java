package ud04;

public class Ej3PrincipalLibro {
    public static void main(String[] args) {
        Ej3Libro l1 = new Ej3Libro("Caperucita Roja", "Anónimo");
        l1.mostrarInformacion();
        System.out.println("-----------------------------------");

        Ej3Libro l2 = new Ej3Libro("El Quijote", "Miguel de Cervantes", 500);
        l2.mostrarInformacion();

        if (l2.esLargo()) {
            System.out.println("El libro es largo.");
        } else {
            System.out.println("El libro es corto.");
        }
    }
}
