package ud04;

public class Ej1PrincipalCuenta {
    public static void main(String[] args) {
        Ej1Cuenta c1 = new Ej1Cuenta();
        Ej1Cuenta c2 = new Ej1Cuenta("Kelea");
        System.out.println(c2);

        c1.ingresarCant(1000);
        c1.setTitular("June");
        System.out.println(c1);
    }
}
