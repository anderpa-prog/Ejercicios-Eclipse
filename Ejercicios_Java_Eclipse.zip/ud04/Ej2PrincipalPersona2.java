package ud04;

public class Ej2PrincipalPersona2 {
    public static void main(String[] args) {
        Ej2Persona2 p1 = new Ej2Persona2();
        p1.setNombre("Kelea");
        p1.setEdad(33);
        p1.setDni("00000000K");
        p1.mostrar();

        if (p1.esMayorDeEdad()) {
            System.out.println("Eres mayor de edad.");
        } else {
            System.out.println("Eres menor de edad.");
        }
    }
}
