package ud04;

public class Ej1Cuenta {
    private String titular;
    private double cantidad;

    public Ej1Cuenta() {
        this.titular = "";
        this.cantidad = 0.0;
    }

    public Ej1Cuenta(String titular) {
        this.titular = titular;
        this.cantidad = 0.0;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Cuenta [titular=" + titular + ", cantidad=" + cantidad + "]";
    }

    public void ingresarCant(double cant) {
        if (cant >= 0) {
            this.cantidad = this.cantidad + cant;
        }
    }

    public void retirar(double cant) {
        this.cantidad = this.cantidad - cant;
        if (this.cantidad < 0) {
            this.cantidad = 0;
        }
    }
}
